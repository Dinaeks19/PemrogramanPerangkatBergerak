package com.example.aplikasimenumakananmanis;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailMakanan extends AppCompatActivity {
    ImageView gambarmakanan_masuk;
    TextView nama_makanan_masuk,deskripsi_makanan_masuk,harga_makanan_masuk;

    String nm_kunci="nmakanan";
    String des_kunci="des";
    String hrg_kunci="harganya";
    int gmakanan;

    String namamakanane;
    String desmakanane;
    String hamakanane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_makanan);

        gambarmakanan_masuk=findViewById(R.id.gambarterima);
        nama_makanan_masuk=findViewById(R.id.nmmakanan);
        deskripsi_makanan_masuk=findViewById(R.id.de_makanan);
        harga_makanan_masuk=findViewById(R.id.har_makanan);

        Bundle bundle=getIntent().getExtras();

        gmakanan=bundle.getInt(String.valueOf("gmakanan"));
        gambarmakanan_masuk.setImageResource(gmakanan);

        namamakanane=bundle.getString("nmakanan");
        desmakanane=bundle.getString("des");
        hamakanane=bundle.getString("harganya");

        nama_makanan_masuk.setText(namamakanane);
        deskripsi_makanan_masuk.setText(desmakanane);
        harga_makanan_masuk.setText(hamakanane);
    }

}