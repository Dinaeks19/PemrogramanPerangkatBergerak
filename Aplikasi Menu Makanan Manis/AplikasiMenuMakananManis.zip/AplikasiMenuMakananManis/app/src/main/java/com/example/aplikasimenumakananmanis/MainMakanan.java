 package com.example.aplikasimenumakananmanis;

 import android.content.Intent;
 import android.os.Bundle;
 import android.view.View;
 import android.widget.AdapterView;
 import android.widget.ListView;

 import androidx.appcompat.app.AppCompatActivity;

 public class MainMakanan extends AppCompatActivity {

     ListView listView;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main_makanan);

         String nama_makanan[] = {"Magical Unicornetto Cupcakes",
                 "Macaron Dessert Box",
                 "Strawberry Ganache"
         };

         int gambar_makanan[] = {R.drawable.cupcakescorn,
                 R.drawable.macarondesertbox,
                 R.drawable.srawberryganache
         };

         String harga_makanan[] = {"Rp 95.000",
                 "Rp 85.000",
                 "Rp 60.000"
         };

         String deskripsi_makanan[] = {" Aww! Lihatlah Magical kami yang lucu\n" +
                 "Unicornetto Cupcakes 4 pcs Cupcakes hanya dengan Rp 95.000.\n" +
                 "\n" +
                 "Dapatkan Magical Unicornetto Cupcakes  kami. Tanpa karbohidrat, bebas gluten dan bebas gula, terbuat dari bahan-bahan terbaik.\n" +
                 "\n" +
                 "Cobalah 4 rasa luar biasa kami:\n" +
                 "cupcake Red Velvet\n" +
                 "cupcake Dark\n" +
                 "Cupcake coklat\n" +
                 "Cupcake kopi\n" +
                 "cupecake Strawberry\n" +
                 "Cupcake kue keju",
                 "Dengan rasa cocoa nyaa, ditambah coffee nyaa dan teksturnyaa lembuut sedikit pahit dan manis asinn cream. Cake lembut dengan 28pcs shell macaron almond aslii dan perpaduan lainnya yang rasanya jadi tambahh enakkkk.\n" +
                 "\n" +
                 "Kue coklat yang lembut ditambah crunchy + gurihnya macaron almond asli ditambah lagi lumeran toblerone yang melipah.\n" +
                 "\n" +
                 "Dapatkan Macaron Dessert Box hanya dengan Rp 85.000",
                 "REKOMEN BANGET strawberry ganache + selai strawberry asli super seger bangettt.\n" +
                 "\n" +
                 "Dengan rasa strawberry, asenm manis gurih perpaduan yang pas. Dengan rasa isian mirip ice cream strawberry yang tengahnya diberi strawberry jam segar asli menbuat teksturnya lembut didalam dan crunchy diluar.\n" +
                 "\n" +
                 "Dapatkan Strawberry ganache 1 box isi 10 pcs hanya dengan Rp 95.000"

         };
         listView = findViewById(R.id.Listdatamakanan);
         AdapterMakanan adapterMakanan = new AdapterMakanan(this, nama_makanan, deskripsi_makanan, harga_makanan, gambar_makanan);
         listView.setAdapter(adapterMakanan);
         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                 String nm_makanan=nama_makanan[position].toString();
                 int gbr_makanan=gambar_makanan[position];
                 String des_makanan=deskripsi_makanan[position].toString();
                 String hrg_makanan=harga_makanan[position].toString();

                 //Toast.makeText(MainMakanan.this, ""+nm_makanan.trim(), Toast.LENGTH_SHORT).show();
                 Intent intent = new Intent(MainMakanan.this, DetailMakanan.class);
                 intent.putExtra("nmakanan",nm_makanan);
                 intent.putExtra("gmakanan",gbr_makanan);
                 intent.putExtra("des",des_makanan);
                 intent.putExtra("harganya",hrg_makanan);
                 startActivity(intent);
             }
         });
     }
 }