package com.example.aplikasibiodataku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Kirim(View view) {
        Intent intent, chooser;
        intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://maps.app.goo.gl/vasBL28wEMWVegXi6"));
        chooser = Intent.createChooser(intent, "Launch Map");
        startActivity(chooser);
    }

    public void Kirim1(View view) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:08996158500"));
        startActivity(intent);
    }

    public void Kirim2(View view) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] {"111202013191@mhs.dinus.ac.id"});
        startActivity(intent);
    }
}