 package com.example.aplikasimenumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Locale;

 public class MainMakanan extends AppCompatActivity {

     ListView listView;

     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main_makanan);

         String nama_makanan[] = {"Cake",
                 "Cookies",
                 "Macaron"
         };

         int gambar_makanan[] = {R.drawable.cake,
                 R.drawable.cookies,
                 R.drawable.macaron
         };

         String deskripsi_makanan[] = {"Bahan White Sponge:\n" +
                 "- 2 butir telur\n" +
                 "- 200 ml susu cair\n" +
                 "- 200 gr tepung terigu\n" +
                 "- 1 sdt pengembang\n" +
                 "- ½ sdt baking powder\n" +
                 "- Sejumput garam\n" +
                 "- 6 sdm gula pasir\n" +
                 "- 4 sdm minyak goreng\n" +
                 "\n"+
                 "- Bahan Isian:\n" +
                 "- Selai coklat\n" +
                 "\n"+
                 "- Bahan Buttercream:\n" +
                 "- 250 gr margarin\n" +
                 "- 4 sdm skm\n" +
                 "- 7 sdm gula halus\n" +
                 "\n"+
                 "Cara Membuat:\n" +
                 "1.  Masukkan telur, pengembang, baking\n" +
                 "     powder, garam, dan gula pasir.\n" +
                 "     Mixer hingga mengembang.\n" +
                 "2.  Kemudian masukkan tepung,\n" +
                 "     mixer dengan kecepatan yang rendah.\n " +
                 "     Masukkan minyak goreng dan susu \n" +
                 "     cair. Aduk adonan menggunakan \n" +
                 "     spatula.\n" +
                 "3.  Panggang adonan menggunakan\n " +
                 "     loyang berbentuk persegi panjang\n" +
                 "     selama 20 menit.\n" +
                 "4.  Jika sudah matang, keluarkan dari\n" +
                 "     oven dan lepaskan dari cetakan.\n" +
                 "5.  Bentuk bulatan dengan menggunakan\n" +
                 "     loyang bulat ukuran 10 cm.\n" +
                 "     Bentuk menjadi 3 bagian.\n" +
                 "6.  Satukan cake dengan memberikan\n" +
                 "     isian selai coklat.\n" +
                 "7.  Campurkan margarin, gula halus dan\n" +
                 "     susu kental manis. Kocok hingga\n" +
                 "     halus.\n" +
                 "8.  Masukkan cake dalam box cake.\n" +
                 "9.  Hias cake dengan cream tersebut\n" +
                 "     sesuai dengan selera.\n" +
                 "10. Korean lunch box cake siap dinikmati.",

                 "Bahan-bahan :\n" +
                 "- Mentega tawar (unsalted butter) - \n" +
                 "   125 gram\n" +
                 "- Gula halus - 125 gram\n" +
                 "- Terigu protein rendah - 200 gram\n" +
                 "- Coklat bubuk - 25 gram\n" +
                 "- Telur - 1 butir\n" +
                 "- Pasta vanilla - 1 sdt\n" +
                 "- Choco chips - 150 gram\n" +
                 "- TOPPING:\n" +
                 "- Choco chips - secukupnya\n" +
                 "\n" +
                 "Langkah \n" +
                 "1.  Campurkan mentega, gula halus,\n" +
                 "     coklat bubuk, telur, dan vanilla. Kocok\n" +
                 "     menggunakan mixer hingga merata. \n" +
                 "2.  Masukkan terigu sambil diayak\n" +
                 "     menggunakan saringan halus, aduk\n" +
                 "     dengan spatula hingga merata.\n" +
                 "3.  Masukkan chocochips, aduk rata\n" +
                 "     kembali.\n" +
                 "4.  Panaskan oven, sisihkan. \n" +
                 "5.  Siapkan loyang, oles tipis dengan\n" +
                 "     margarin. \n" +
                 "6.  Ambil 1 sdt adonan dan taruh ke atas\n" +
                 "     loyang. Pipihkan menggunakan\n" +
                 "     garpu atau ujung jari tangan. Lakukan\n" +
                 "     hingga semua adonan habis. \n" +
                 "7.  Taburi chocochips di atas tiap cookies. \n" +
                 "8.  Panggang kue dalam oven dengan\n" +
                 "     suhu 170°C selama 30 menit hingga\n" +
                 "     matang. Angkat. \n" +
                 "9.  Siap disajikan atau bisa disimpan\n" +
                 "     dalam toples kedap udara setelah\n" +
                 "     kue dingin. \n" +
                 "10. Pastikan mentega yang digunakan\n" +
                 "     tidak bersuhu dingin atau telah\n" +
                 "     dikeluarkan beberapa saat dalam\n" +
                 "     suhu ruang, sebelum dikocok bersama\n" +
                 "     bahan-bahan lain. ",

                 "Bahan :\n" +
                 "Lemon Butter Cream\n" +
                 "- Shortening Putih\t400 gr\n" +
                 "- Susu Kental Manis\t250 gr\n" +
                 "- Margarin untuk Kue\t100 gr\n" +
                 "\n"+
                 "Lemon Syrup\n" +
                 "- Air perasan jeruk lemon\t50 gr\n" +
                 "- Air\t50 gr\n" +
                 "- Gula\t200 gr\n" +
                 "- Lemon Zest\t1 buah\n" +
                 "- Lemon Essence\t5 gr\n" +
                 "\n"+
                 "Membuat French Macaron\n" +
                 "- Putih Telur\t100 gr\n" +
                 "- Cream of tartar\t1 gr\n" +
                 "- Gula\t100 gr\n" +
                 "- Gula halus\t110 gr\n" +
                 "- Almond Bubuk Halus\t130 gr\n" +
                 "\n"+
                 "Lemon Butter Cream\n" +
                 "1.  Campur bahan bersama-sama.\n" +
                 "\n" +
                 "Lemon Syrup\n" +
                 "1.  Campur bahan bersama-sama.\n" +
                 "\n" +
                 "Membuat French Macaron\n" +
                 "1.  Kocok putih telur dan cream of tartar\n " +
                 "     hingga berbuih, lalu masukkan gula, \n" +
                 "     kocok hingga medium peak.\n" +
                 "2.  Ayak icing sugar dan almond bubuk, \n" +
                 "     masukkan secara bertahap ke dalam \n" +
                 "     kocokan putih telur. \n" +
                 "3.  Aduk rata hingga mencapai konsistensi \n" +
                 "     adonan mengalir perlahan seperti lava. \n" +
                 "4.  Beri pewarna sesuai keinginan.\n" +
                 "5.  Pipe adonan menjadi bentuk hati\n" +
                 "     ke atas loyang yang dialasi\n" +
                 "     parchment paper.\n" +
                 "6.  Hentak loyang untuk mengeluarkan\n" +
                 "     gelembung udara.\n" +
                 "7.  Diamkan selama 30 menit hingga\n" +
                 "     tidak lengket  saat disentuh.\n" +
                 "8.  Panggang pada suhu 160°C selama\n" +
                 "     5 menit lalu turunkan suhu menjadi\n" +
                 "     150°C dan panggang selama 10 menit.\n" +
                 "9.  Diamkan di atas loyang hingga dingin.\n" +
                 "     Beri lemon butter cream filling.\n" +
                 "\n" +
                 "Membuat Lemon Butter Cream\n" +
                 "1.  Masak semua bahan lemon syrup\n" +
                 "     hingga gula larut, dinginkan." +
                 "2.  Kocok shortening putih dan margarin\n" +
                 "     hingga mengembang.\n" +
                 "3.  Masukkan susu kental manis, lemon\n" +
                 "     syrup, dan lemon essence, aduk rata.",
         };

         listView = findViewById(R.id.Listdatamakanan);
         AdapterMakanan adapterMakanan = new AdapterMakanan(this, nama_makanan, deskripsi_makanan, gambar_makanan);
         listView.setAdapter(adapterMakanan);
         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                 String nm_makanan=nama_makanan[position].toString();
                 int gbr_makanan=gambar_makanan[position];
                 String des_makanan=deskripsi_makanan[position].toString();

                 //Toast.makeText(MainMakanan.this, ""+nm_makanan.trim(), Toast.LENGTH_SHORT).show();
                 Intent intent = new Intent(MainMakanan.this, DetailMakanan.class);
                 intent.putExtra("nmakanan",nm_makanan);
                 intent.putExtra("gmakanan",gbr_makanan);
                 intent.putExtra("des",des_makanan);
                 startActivity(intent);
             }
         });
     }
 }