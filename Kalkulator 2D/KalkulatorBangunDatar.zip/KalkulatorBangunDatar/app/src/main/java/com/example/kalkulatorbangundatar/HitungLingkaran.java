package com.example.kalkulatorbangundatar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HitungLingkaran extends AppCompatActivity {

    private EditText jari2;
    private TextView luasnya;
    private TextView kelilingnya;
    private Button hasilluas;
    private Button hasilkeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hitung_lingkaran);
        jari2 = (EditText) findViewById(R.id.jari2);
        luasnya = (TextView) findViewById(R.id.luasnya);
        kelilingnya = (TextView) findViewById(R.id.kelilingnya);
        hasilluas = (Button) findViewById(R.id.hasilluas);
        hasilkeliling = (Button) findViewById(R.id.hasilkeliling);

    }

    public void Kirim(View view) {
        try {
            int r = Integer.parseInt(jari2.getText().toString());
            double hasilluas = 22*(r*r)/7;
            luasnya.setText(String.valueOf(hasilluas));
        } catch (Exception e){
            e.printStackTrace();
        }
    }


    public void Kirim2(View view) {
        try {
            int r = Integer.parseInt(jari2.getText().toString());
            double hasilkeliling = 22*(2*r)/7;
            kelilingnya.setText(String.valueOf(hasilkeliling));
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}